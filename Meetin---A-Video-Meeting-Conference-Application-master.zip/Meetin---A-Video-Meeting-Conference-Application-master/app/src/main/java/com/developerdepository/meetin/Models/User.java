package com.developerdepository.meetin.Models;

import java.io.Serializable;

public class User implements Serializable {
    public String Name, Email, Mobile, FCMToken, Username, About, Image;
}
